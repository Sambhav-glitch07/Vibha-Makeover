import { createClient } from '@supabase/supabase-js';

const clean = (value, max = 500) => String(value ?? '').replace(/[\r\n]+/g, ' ').trim().slice(0, max);

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ error: 'Method not allowed.' });
  }
  const origin = req.headers.origin;
  const allowed = (process.env.SITE_URL || '').replace(/\/$/, '');
  if (allowed && origin && origin.replace(/\/$/, '') !== allowed) {
    return res.status(403).json({ error: 'Origin not allowed.' });
  }
  const body = req.body || {};
  if (clean(body.company_website, 200)) return res.status(200).json({ ok: true });
  const name = clean(body.name, 80);
  const phone = clean(body.phone, 25);
  const event = clean(body.event, 80);
  const date = clean(body.date, 10) || null;
  const message = clean(body.message, 1000);
  if (!name || !phone || !event) return res.status(400).json({ error: 'Name, phone and occasion are required.' });
  if (!/^[+()\-\s\d]{7,25}$/.test(phone)) return res.status(400).json({ error: 'Enter a valid contact number.' });
  if (date && !/^\d{4}-\d{2}-\d{2}$/.test(date)) return res.status(400).json({ error: 'Enter a valid event date.' });
  const { SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY } = process.env;
  if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) return res.status(500).json({ error: 'Booking database is not configured.' });
  const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, { auth: { persistSession: false } });
  const { data: booking, error } = await supabase.from('bookings').insert({ name, phone, event, date, message: message || null, status: 'Pending' }).select('id').single();
  if (error) {
    console.error('Booking insert failed:', error.message);
    return res.status(500).json({ error: 'Could not save your booking. Please try again.' });
  }
  // Booking is persisted first. A WhatsApp failure does not lose the booking.
  let whatsappSent = false;
  const { WHATSAPP_TOKEN, WHATSAPP_PHONE_NUMBER_ID, WHATSAPP_RECIPIENT, GRAPH_API_VERSION } = process.env;
  if (WHATSAPP_TOKEN && WHATSAPP_PHONE_NUMBER_ID && WHATSAPP_RECIPIENT && GRAPH_API_VERSION) {
    try {
      const response = await fetch(`https://graph.facebook.com/${GRAPH_API_VERSION}/${WHATSAPP_PHONE_NUMBER_ID}/messages`, {
        method: 'POST', headers: { Authorization: `Bearer ${WHATSAPP_TOKEN}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ messaging_product: 'whatsapp', recipient_type: 'individual', to: WHATSAPP_RECIPIENT, type: 'template', template: { name: process.env.WHATSAPP_TEMPLATE_NAME || 'vibha_booking_alert', language: { code: process.env.WHATSAPP_TEMPLATE_LANGUAGE || 'en' }, components: [{ type: 'body', parameters: [
          { type: 'text', text: name }, { type: 'text', text: phone }, { type: 'text', text: event }, { type: 'text', text: date || 'Not specified' }, { type: 'text', text: message || 'No extra details' }
        ] }] } })
      });
      const result = await response.json(); whatsappSent = response.ok;
      if (!response.ok) console.error('WhatsApp notification error:', result);
    } catch (err) { console.error('WhatsApp notification failed:', err.message); }
  }
  return res.status(200).json({ ok: true, bookingId: booking.id, whatsappSent });
}
